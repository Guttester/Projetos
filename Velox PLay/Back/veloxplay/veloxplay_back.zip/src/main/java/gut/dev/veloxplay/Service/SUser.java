package gut.dev.veloxplay.Service;

import java.util.List;
import java.util.Optional;

import gut.dev.veloxplay.Model.User;
import gut.dev.veloxplay.Repository.RUser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SUser {
    @Autowired
    private RUser repositoryUser;
    
    public List<User> findAll(){ return repositoryUser.findAll(); }
    public Optional<User> findById(Long id){ return repositoryUser.findById(id); }
    public User save(User obj){ return repositoryUser.save(obj); }
    public void deleteById(Long id){ repositoryUser.deleteById(id); }
}