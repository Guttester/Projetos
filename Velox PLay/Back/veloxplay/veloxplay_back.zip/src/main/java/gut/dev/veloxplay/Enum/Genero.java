package gut.dev.veloxplay.Enum;

public enum Genero {
    ACAO, COMEDIA, DRAMA, ROMANCE, FICCAO, TERROR
}