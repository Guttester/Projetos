package gut.dev.veloxplay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeloxplayApplicationTests {

	@Test
	void contextLoads() {
	}

}
